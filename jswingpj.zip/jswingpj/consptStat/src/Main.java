public class Main {

    public static void main(String[] args) {

        IDandpass idandpass = new IDandpass();
        LoginPage loginPage = new LoginPage(idandpass.getLoginInfo());

}

}