import java.util.HashMap;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPage implements ActionListener{

    JFrame frame = new JFrame();
    JButton loginButton = new JButton("Login");
    JButton forgotButton = new JButton("Forgot Password");
    JTextField userIDField = new JTextField("quanly1");
    JPasswordField userPasswordField = new JPasswordField("123");
    JLabel userIDLabel = new JLabel("userID:");
    JLabel userPasswordLabel = new JLabel("password:");
    JLabel messageLabel = new JLabel("");
    HashMap<String, String> logininfo = new HashMap<String, String>();


    LoginPage(HashMap<String, String> loginInfoOriginal) {
        
        logininfo = loginInfoOriginal;

        frame.setSize(1280, 720);
        frame.setLayout(null);
        int x = (frame.getWidth() - 500) / 2;
        int y = (frame.getHeight() - 300) / 2;

        userIDLabel.setBounds(x, y, 75, 25);
        userPasswordLabel.setBounds(x, y + 50, 75, 25);

        messageLabel.setBounds(x + 175, y + 200, 250, 35);
        messageLabel.setFont(new Font("serif", Font.ITALIC, 25));
        
        userIDField.setBounds(x + 175, y, 200, 25);
        userPasswordField.setBounds(x + 175, y + 50, 200, 25);
        
        loginButton.setBounds(x + 175, y + 100, 100, 25);
        loginButton.addActionListener(this);

        forgotButton.setBounds(x + 300, y + 100, 100, 25);
        forgotButton.setFocusable(false);
        forgotButton.addActionListener(this);

        frame.add(userIDLabel);
        frame.add(userPasswordLabel);
        frame.add(messageLabel);
        frame.add(userIDField);
        frame.add(userPasswordField);
        frame.add(loginButton);
        frame.add(forgotButton);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }



    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==forgotButton){
            userIDField.setText("");
            userPasswordField.setText("");
        }

        if(e.getSource()==loginButton){

            String userID = userIDField.getText();
            String password = String.valueOf(userPasswordField.getPassword());

            if(logininfo.containsKey(userID)) {
                if(logininfo.get(userID).equals(password)) {
                    messageLabel.setText("Login Successful");
                    messageLabel.setForeground(Color.green);
                    HomePage homePage = new HomePage();
                    frame.dispose();
                }
                else {
                    messageLabel.setText("Wrong id or Password");
                    messageLabel.setForeground(Color.red);
                }
            }
            else {
                messageLabel.setText("Cant find id");
                messageLabel.setForeground(Color.red);
            }
        }

        
    }
}