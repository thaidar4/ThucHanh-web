import java.util.HashMap;

public class IDandpass {

    HashMap<String, String> logininfo = new HashMap<String, String>();

    IDandpass() {

        logininfo.put("quanly1", "123");

    }

    protected HashMap getLoginInfo() {

        return logininfo;
    }
}