import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePage implements ActionListener {
    
    JFrame frame = new JFrame();
    JLabel welcomLabel = new JLabel("Họ và tên: Nguyễn Văn A");
    JButton makelistButton = new JButton("Tạo danh sách thống kê");
    JButton logoutButton = new JButton("Đăng xuất");

    HomePage() {
        
        welcomLabel.setBounds(30, 20, 250, 50);
        welcomLabel.setFont(new Font("serif", Font.PLAIN, 25));
        makelistButton.setBounds(30, 100, 180, 25);
        logoutButton.setBounds(30, 600, 100, 25);

        frame.add(welcomLabel);
        frame.add(makelistButton);
        frame.add(logoutButton);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1280, 720);
        frame.setLayout(null);
        frame.setVisible(true);

        makelistButton.addActionListener(this);
        logoutButton.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == logoutButton) {
            LoginPage loginPage = new LoginPage(new IDandpass().getLoginInfo());
            frame.dispose();
        }

        
    }


}
